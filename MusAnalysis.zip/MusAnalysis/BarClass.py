import numpy as np


class Bar:
    def __init__(self, tempo_ticks=-1, numerator=-1, denominator=-1):
        self.lengths = []
        self.notes = []
        self.tempo_ticks = tempo_ticks
        self.numerator = numerator
        self.denominator = denominator
        self.bar_size = numerator / denominator
        self.transformed_notes = []

    def set_lengths(self, new_bar):
        self.lengths = new_bar

    def set_notes(self, new_bar):
        self.notes = new_bar

    def set_tempo(self, tempo_ticks):
        self.tempo_ticks = tempo_ticks

    def set_numerator(self, numerator):
        self.numerator = numerator
        # experimental
        self.bar_size = self.numerator / self.denominator

    def set_denominator(self, denominator):
        self.denominator = denominator
        # experimental
        self.bar_size = self.numerator / self.denominator

    def add_to_lengths(self, note):
        self.lengths.append(note)

    def add_to_notes(self, note):
        self.notes.append(note)

    def transform_notes(self):
        transformed = []
        for i in range(0, len(self.lengths)):
            for j in range(0, int(self.lengths[i] / (1. / 64))):
                transformed.append(self.notes[i])
        self.transformed_notes = transformed

    def lengths_sum(self):
        result = 0
        for elem in self.lengths:
            result += elem
        return result

    def get_remaining_length(self):
        return self.bar_size - self.lengths_sum()

    def copy_parameters(self, bar):
        self.numerator = bar.numerator
        self.denominator = bar.denominator
        self.tempo_ticks = bar.tempo_ticks

    def make_pause(self):
        self.lengths = [self.bar_size]
        self.notes = [0]

    def is_pause(self):
        if self.notes == [0]:
            return True
        else:
            return False

    def mean_note_length(self):
        return np.mean(self.lengths)

    def mean_note_value(self):
        simplified = []
        for i in self.notes:
            simplified.append(np.mean(i))
        return np.mean(simplified)

    def note_type_ratio(self, arg):
        result = 0
        if arg == 'single':
            for i in range(len(self.notes)):
                if self.notes[i] != 0:
                    if len(self.notes[i]) == 1:
                        result += self.lengths[i]
        if arg == 'chord':
            for i in range(len(self.notes)):
                if self.notes[i] != 0:
                    if len(self.notes[i]) > 1:
                        result += self.lengths[i]

        if arg == 'pause':
            for i in range(len(self.notes)):
                if self.notes[i] == 0:
                    result += self.lengths[i]

        return result / self.bar_size

    def pure_notes(self):
        result = []
        for chord in self.notes:
            if chord != 0:
                for note in chord:
                    result.append(note % 12)
        if len(result) == 0:
            result = [-1]
        return sorted(set(result))

    def get_min_note(self):
        return min(self.get_all_notes())

    def get_max_note(self):
        return max(self.get_all_notes())

    def get_all_notes(self, include_nulls=True):
        notes = []
        for chord in self.notes:
            if chord != 0:
                for note in chord:
                    notes.append(note)
            elif include_nulls:
                notes.append(0)
        return notes

    def median_note(self):
        notes = []
        for chord in self.notes:
            if chord != 0:
                for note in chord:
                    notes.append(note)
            else:
                notes.append(0)

        notes = sorted(notes)
        # print(notes)
        # print(np.median(notes))
        return np.median(notes)

    def moda(self):
        notes = []

        for chord in self.notes:
            if chord != 0:
                for note in chord:
                    notes.append(note)
            else:
                notes.append(0)

        note_counter = {}
        for word in notes:
            if word in note_counter:
                note_counter[word] += 1
            else:
                note_counter[word] = 1

        popular_notes = sorted(note_counter, key=note_counter.get, reverse=True)

        return popular_notes[0]
