import os

from Analyse import SongAnalyzer

path = '~/Desktop/MusAnalysis/AllSongs'

failed = 0
maxChange = 0
maxName = ''
ts_change = 0
max_ts_change = 0
max_sig_name = ''
bothChange = 0

for folder in os.listdir(os.path.expanduser(path)):
    npath = path + '/' + folder
    # print(folder)
    try:
        sa = SongAnalyzer(os.path.expanduser(npath))
        number_of_tempo_changes, change = sa.get_all_tempos()
        number_of_sign_changes, sign = sa.getAll_time_signatures()
        # print(str(a) + " " + str(b))
        if number_of_tempo_changes > 1:
            failed += 1
            print(npath + " - tempo change")
        if number_of_tempo_changes > maxChange:
            maxChange = number_of_tempo_changes
            maxName = npath
        if number_of_sign_changes > 1:
            ts_change += 1
            print(npath + " - signature change")
        if number_of_sign_changes > max_ts_change:
            max_ts_change = number_of_sign_changes
            max_sig_name = npath
        if number_of_tempo_changes > 1 and number_of_sign_changes > 1:
            bothChange += 1
    except:
        continue

print('total tracks with both tempo and signature change: ' + str(bothChange))
print('total tracks with tempo change: ' + str(failed))
print('maximum changing tracks: ' + str(maxChange) + ' ' + maxName)
print('total tracks with signature change: ' + str(ts_change))
print('maximum changing signatures: ' + str(max_ts_change) + ' ' + max_sig_name)


# for filename in glob.glob(os.path.join('~/Desktop/MusAnalysis/MIDIS/Hard', '*.mid')):
#     print(filename)
#     for file in glob.glob(os.path.join(path + '/' + filename, '*.mid')):
#         print(file)
