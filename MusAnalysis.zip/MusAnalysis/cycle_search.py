from analysis_assistant import *
from NoteBasedComparison import *


def get_parts_list(dataset_line, part):
    result = []
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == part + ':':
            result = dataset_line[i + 1].split(',')
            break

    if result == []:
        return [-1]
    # if ',' in result:
    #     result = result.split(',')
    blocks = []
    for i in result:
        diap = i.split('-')
        blocks.append([int(diap[0]) - 1, int(diap[1])])

    return blocks


midi = 'deep_purple-perfect_strangers.mid'
test_song = fill_song(midi)
line = 'deep_purple-perfect_strangers.mid intro: 1-5 verse: 5-25,26-44,65-83 chorus: 45-55,84-94 ' \
       'bridge: 56-64,95-123  structure: ivvcbvcb'.split(" ")

bar_list = get_parts_list(line, 'verse')
print(bar_list)
bars = one_track_equality_test(test_song.tracks[1])
test_bars = []
for i in range(bar_list[0][0], bar_list[0][1]):
    test_bars.append(bars[i])

print(test_bars)


def find_cycles(equalities):

    has_copies = []
    amounts = []

    for i in range(2, len(equalities) // 2 + 1):
        cycles = []
        for j in range(len(equalities) - i + 1):
            current = []
            for k in range(j, j + i):
                current.append(equalities[k])
            cycles.append(current)

        for j in range(len(cycles)):
            for k in range(j + 1, len(cycles)):
                if cycles[j] == cycles[k]:
                    if cycles[j] not in has_copies:
                        has_copies.append(cycles[j])
                        amounts.append(1)
                    else:
                        amounts[has_copies.index(cycles[j])] += 1

                elif cycles[j][:len(cycles[i])//2] == cycles[k][:len(cycles[j])//2]:
                    new = cycles[j][:len(cycles[i])//2].append("*")
                    if new not in has_copies:
                        has_copies.append(new)
                        amounts.append(1)
                    else:
                        amounts[has_copies.index(new)] += 1

    amounts, has_copies = (list(t) for t in zip(*sorted(zip(amounts, has_copies))))
    print(has_copies)
    print(amounts)


find_cycles(test_bars)
