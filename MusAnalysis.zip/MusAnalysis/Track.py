class Track:
    def __init__(self, name="track", midi_program=0):
        self.bars = []
        self.name = name
        self.midi_program = midi_program

    def set_midi_program(self, midi_program):
        self.midi_program = midi_program

    def addBar(self, bar):
        self.bars.append(bar)

    def get_bars(self):
        return self.bars

    def update_with(self, track):
        self.bars = track.bars

    def get_emptiness(self):
        result = 0
        size = len(self.bars)
        for bar in self.bars:
            if bar.is_pause():
                result += 1
        return result / size

    def get_all_notes(self):
        notes = []
        for bar in self.bars:
            bar_notes = bar.get_all_notes(False)
            for note in bar_notes:
                notes.append(note)

        return notes
