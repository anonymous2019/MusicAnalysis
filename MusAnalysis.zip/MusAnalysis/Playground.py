from Filling import *
import os
import NoteBasedComparison as nbc
import Tonality_check as tc
from making_сlusteing import *
import itertools
import Plotting
import numpy as np
import Markov as mk

import copy

#
# midi = 'deep_purple-perfect_strangers.mid'
# midi = "Dragonforce - Through the Fire and Flames (Version 1).mid"
# midi = "avantasia-farewell.mid"
# midi = 'acdc-highway_to_hell.mid'
# midi = 'Dark Moor - Before The Duel v1.mid'
# midi = 'avantasia-sign_of_the_cross.mid'
# midi = 'guns_n_roses-nightrain.mid'
# midi = '99 Ways to Die.mid'

# test_song = fill_song(midi)


def plot_em_all():
    path = '~/Desktop/MusAnalysis/AllHard'
    savepath = 'HardPlots'

    count = 1
    for folder in os.listdir(os.path.expanduser(path)):
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            print(str(count) + "th done")
            count += 1

            song_folder = savepath + "/" + folder[:-4]

            if not os.path.exists(song_folder):
                os.makedirs(song_folder)

            tracks = song.remove_bad_tracks()

            for i in range(1, len(tracks) + 1):
                for subset in itertools.combinations(tracks, i):
                    chosen = list(subset)
                    naming = ""
                    for track in chosen:
                        naming += track.name + "_"
                    data = custom_tracks_features(chosen)
                    labels = mean_shift(data)
                    # labels = do_clustering(data, 4)
                    Plotting.draw_simple(labels, True, song_folder + "/ms_" + naming)


        except Exception as exception:
            print(exception)
            continue


def test_stuff_over_dataset():
    path = '~/Desktop/MusAnalysis/AllHard'
    for folder in os.listdir(os.path.expanduser(path)):
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            tonality_check(song)
        except Exception as exception:
            print(exception)
            continue


def drum_check():
    path = '~/Desktop/MusAnalysis/AllHard'
    for folder in os.listdir(os.path.expanduser(path)):
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            print(song.tracks[len(song.tracks) - 1].name + " " + str(song.tracks[len(song.tracks) - 1].midi_program))
        except Exception as exception:
            print(exception)
            continue


def another_tonality():
    path = '~/Desktop/MusAnalysis/AllHard'
    for folder in os.listdir(os.path.expanduser(path)):
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))

            stuff = tc.track_tonalities(test_song.tracks[0])
            all = tc.all_tonalities(stuff)

            tonalities = []
            count = []

            # for i in all:
            #   if i not in

        except Exception as exception:
            print(exception)
            continue


def tonality_check(song):
    print(song.name)
    notes, values = note_counter_song(song)
    # for i in range(0, len(notes)):
    # print(str(notes[i]) + " - " + str(values[i]) + " times")
    print(np.mean(values))
    print("-" * 20)
    result = []
    for i in range(0, len(notes)):
        if values[i] > np.mean(values):
            result.append(notes[i] % 12)

    print(sorted(set(result)))


def voting_system(structures):
    str_num = len(structures)
    result = list(range(0, len(structures[0])))
    for i in range(len(structures[0])):

        for j in range(i + 1, len(structures[0])):
            agrees = 0
            for structure in structures:
                try:
                    if structure[i] == structure[j]:
                        agrees += 1
                except:
                    continue
            if agrees / str_num > 0.7:
                result[j] = result[i]

    return result


def check_instrument_entry(song, bars):
    y = []
    for track in song.tracks:
        y.append(track.name)
    x = [0] * len(y)
    xlabel = "number of bars"
    title = "instrument presence in song part"
    for diap in bars:
        for i in range(diap[0], diap[1]):
            for j in range(len(song.tracks)):
                if not song.tracks[j].bars[i].is_pause():
                    x[j] += 1

    Plotting.make_plot_horizontal(y, x, title, xlabel, 1)


def check_notes(song, bars, instr_num):
    y = []
    x = [0] * len(y)
    xlabel = "times appeared"
    title = "notes/chords in song part for Flute"
    notes = []
    for diap in bars:
        for i in range(diap[0], diap[1]):
            notes.append(song.tracks[instr_num].bars[i].get_all_notes())
    notes = sorted(notes)
    current = notes[0]
    count = 0
    for note in notes:
        if note == current:
            count += 1
        else:
            x.append(count)
            y.append(current)
            current = note
            count = 1
    Plotting.make_plot_horizontal(y, x, title, xlabel, 1)


def check_durations(song, bars, instr_num):
    y = []
    x = [0] * len(y)
    xlabel = "number of bars"
    title = "Note durations in bars in song part for Flute"
    durations = []
    for diap in bars:
        for i in range(diap[0], diap[1]):
            durations.append(song.tracks[instr_num].bars[i].lengths)
    durations = sorted(durations)
    current = durations[0]
    count = 0
    for note in durations:
        if note == current:
            count += 1
        else:
            x.append(count)
            y.append(current)
            current = note
            count = 1
    Plotting.make_plot_horizontal(y, x, title, xlabel, 1)


# для гитар
def leading_instrument(tracks):
    max = 0
    result = -1
    for track in tracks:
        notes = track.get_all_notes()
        mean_note = np.mean(notes)
        if mean_note > max:
            max = mean_note
            result = track

    return result



def note_counter(track):
    notes = sorted(track.get_all_notes())
    count = 1
    current = notes[0]
    result_notes = []
    result_values = []
    for note in notes:
        if current == note:
            count += 1
        if current != note:
            result_notes.append(current)
            result_values.append(count)
            current = note
            count = 1
    return result_notes, result_values


def note_counter_song(song):
    result_notes = []
    result_values = []
    for track in song.tracks:
        if 113 <= track.midi_program <= 120 or track.midi_program == 0:
            continue
        notes, values = note_counter(track)
        for note in notes:
            result_notes.append(note)
        for value in values:
            result_values.append(value)
    return result_notes, result_values

def get_parts(dataset_line, part):
    result = []
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == part + ':':
            result = dataset_line[i + 1].split(',')
            break
    if result == []:
        return [-1]
    blocks = []
    for i in result:
        diap = i.split('-')
        blocks.append([int(diap[0]), int(diap[1])])
    return blocks


def get_structure(dataset_line):
    result = []
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == 'structure:':
            result = dataset_line[i + 1]
    structure = list()

    structure.append('START')

    vc = 0
    cc = 0
    sc = 0
    mc = 0
    bc = 0
    for i in result:
        if i == 'i':
            structure.append('intro')
        if i == 'v':
            structure.append('verse' + str(vc))
            vc += 1
        if i == 'b':
            structure.append('bridge' + str(bc))
            bc += 1
        if i == 'c':
            structure.append('chorus' + str(cc))
            cc += 1
        if i == 's':
            structure.append('solo' + str(sc))
            sc += 1
        if i == 'o':
            structure.append('outro')
        if i == 'm':
            structure.append('middle_eight' + str(mc))
            mc += 1
    structure.append('END')
    return structure


def all_structures():
    path = '~/Desktop/MusAnalysis/AllHard'
    result = []
    for folder in os.listdir(os.path.expanduser(path)):

        print(folder)
        if folder == '.DS_Store':
            continue
        try:
            f = open('Dataset_Hard', 'r')
            while True:
                a = f.readline()
                if a == '\n' or a == '':
                    f.close()
                    break
                a = a.split(" ")
                if a[0] == folder:
                    structure = get_structure(a)
                    print(structure)
                    result += structure
                    f.close()
                    break
            f.close()
            continue
        except Exception as exception:
            print(exception)
            continue
    return result


def song_tempos(song):
    tempos = []
    track = song.tracks[0].bars
    for bar in track:
        if bar.tempo_ticks not in tempos:
            tempos.append(bar.tempo_ticks)
    result = []
    result.append('START')
    for i in tempos:
        result.append(str(i))
    result.append('END')
    return result


def all_song_tempos():
    path = '~/Desktop/MusAnalysis/AllHard'
    result = []
    for folder in os.listdir(os.path.expanduser(path)):
        print(folder)
        if folder == '.DS_Store':
            continue
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            result += song_tempos(song)  # +=

        except Exception as exception:
            print(exception)
            continue
    return result


def song_instruments(song):
    instruments = []
    for track in song.tracks:
        instruments.append(str(track.midi_program))

    result = []
    result.append('START')
    for i in instruments:
        result.append(str(i))
    result.append('END')
    return result


def all_song_instruments():
    path = '~/Desktop/MusAnalysis/AllHard'
    result = []
    for folder in os.listdir(os.path.expanduser(path)):
        print(folder)
        if folder == '.DS_Store':
            continue
        try:
            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            result += song_instruments(song)

        except Exception as exception:
            print(exception)
            continue
    return result


# ----- making the structure markov
# data = all_structures()
# mm = mk.make_markov_model(data)
# sentence = mk.generate_any_sentence(mm)
# print(sentence)
# ----- markov for tempos
# a = ['START', '12345', 'END', 'START', '12125', 'END', 'START', '12666', 'END', 'START', '12345', '12345', 'END']
# data = all_song_tempos()
# print(data)
# mm = mk.make_markov_model(data)
# sentence = mk.generate_any_sentence(mm)
# print(sentence)
# --- markov for instruments
# упорядоч набор, комбинация инструментов
# data = all_song_instruments()
# mm = mk.make_markov_model(data)
# sentence = mk.generate_any_sentence(mm)
# print(sentence)
