
class Combinator():
    def __init__(self, main):
        self.main = main
        self.children = list()
        self.amounts = list()

    def add(self, child):
        if child not in self.children:
            self.children.append(child)
            self.amounts.append(1)
        else:
            self.amounts[self.children.index(child)] += 1

    def is_same(self, combinator):
        if self.main == combinator.main:
            return True
        else:
            return False

    def get_amounts_percents(self):
        total = sum(self.amounts)
        result = []
        for i in self.amounts:
            result.append(i/total*100)
        return result

    def get_children(self):
        return self.children