from OtherStuff import *


def program_to_group(midi_prigram):
    if 1 <= midi_prigram <= 8:
        return 'P'  # 'Piano'
    if 9 <= midi_prigram <= 16:
        return 'CP'  # 'Chromatic Percussion'
    if 17 <= midi_prigram <= 24:
        return 'O'  # 'Organ'
    if 25 <= midi_prigram <= 32:
        return 'G'  # 'Guitar'
    if 33 <= midi_prigram <= 40:
        return 'B'  # 'Bass'
    if 41 <= midi_prigram <= 48:
        return 'S'  # 'Strings'
    if 49 <= midi_prigram <= 56:
        return 'E'  # 'Ensemble'
    if 57 <= midi_prigram <= 64:
        return 'BR'  # 'Brass'
    if 65 <= midi_prigram <= 72:
        return 'R'  # 'Reed'
    if 73 <= midi_prigram <= 80:
        return 'P'  # 'Pipe'
    if 81 <= midi_prigram <= 88:
        return 'Sl'  # 'Synth Lead'
    if 89 <= midi_prigram <= 96:
        return 'SP'  # 'Synth Pad'
    if 97 <= midi_prigram <= 104:
        return 'SE'  # 'Synth Effects'
    if 105 <= midi_prigram <= 112:
        return 'ETH'  # 'Ethnic'
    else:
        return 'D'  # 'Drums'


def instruments_in(set, list):
    for i in range(len(list)):
        if len(list[i]) != len(set):
            continue
        else:
            gotit = True
            for j in range(len(set)):
                if list[i][j] != set[j]:
                    gotit = False
            if gotit:
                return i
    return -1


def check_if_in(list, combinator):
    for i in range(len(list)):
        if combinator.is_same(list[i]):
            return i
    return -1


def get_raw_structure(dataset_line):
    result = list()
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == 'structure:':
            result = dataset_line[i + 1]  # .replace('m', 'b')
    return result[0:-1]


def analysis_structure():
    path = '~/Desktop/MusAnalysis/AllHard'

    structures = list()
    structures_count = list()

    part_presence = list()
    part_count = list()

    for folder in os.listdir(os.path.expanduser(path)):
        try:

            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            structure = list()  # structure is here
            raw_structure = list()
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    structure = get_structure(line, numbered=False)
                    raw_structure = get_raw_structure(line)
                    f.close()
                    break

            f.close()

            # song = fill_song(os.path.expanduser(npath))
            structure_set = set(structure)
            for str in structure_set:
                str_comb = Combinator(str)
                index = check_if_in(part_presence, str_comb)
                if index == -1:
                    part_presence.append(str_comb)
                    part_count.append(1)
                else:
                    part_count[index] += 1

            for i in part_presence:
                if structure != []:
                    current = i.main
                    counter = 0

                    for j in structure:
                        if j == current:
                            counter += 1
                    i.add(counter)
                    if i.main == 'chorus' and counter == 1:
                        print(folder)

            str_comb = Combinator(raw_structure)
            # print(folder)
            # print(raw_structure)
            # print('--'*15)

            if str_comb.main != []:

                i = check_if_in(structures, str_comb)
                if i == -1:
                    structures.append(str_comb)
                    structures_count.append(1)
                else:
                    structures_count[i] += 1

            else:
                print(folder)




        except Exception as exception:
            print(folder)
            print(line)
            print(exception)
            continue

    structures_raw = list()
    for i in structures:
        structures_raw.append(i.main)

    lengths = []
    for i in structures_raw:
        lengths.append(len(i))

    total = sum(structures_count)
    percents = []
    for i in structures_count:
        percents.append(i / total * 100)

    lengths, percents, structures_raw = \
        (list(t) for t in zip(*sorted(zip(lengths, percents, structures_raw))))

    xlabel = "Amount, %"
    tit = ''
    title = "Different types of structures"
    Plotting.make_plot_vertical(percents, structures_raw, tit, xlabel)

    pp_raw = list()
    for i in part_presence:
        pp_raw.append(i.main)

    xlabel = "Amount, %"
    tit = ''
    title = "Presence of parts in songs"

    part_count, pp_raw = \
        (list(t) for t in zip(*sorted(zip(part_count, pp_raw))))

    Plotting.make_plot_vertical(part_count, pp_raw, tit, xlabel)

    for i in part_presence:
        xlabel = "Amount, %"
        title = "The amount of " + i.main + " in songs"
        amounts = i.amounts
        children = i.children
        children, amounts = (list(t) for t in zip(*sorted(zip(children, amounts))))
        # Plotting.make_plot_vertical(amounts, children, ' ', xlabel, save=True, name=title)


def analysis_instruments():
    path = '~/Desktop/MusAnalysis/AllHard'

    instruments = list()
    instruments_count = list()
    instrument_presence = list()
    presence_count = list()

    for folder in os.listdir(os.path.expanduser(path)):
        # print(folder)

        try:

            npath = path + '/' + folder
            song = fill_song(os.path.expanduser(npath))
            instr = sorted(song.get_instruments())
            instr_groups = list()
            for i in instr:
                instr_groups.append(program_to_group(i))
            instr_set = set(instr_groups)

            for instrument in instr_set:
                if instrument not in instrument_presence:
                    instrument_presence.append(instrument)
                    presence_count.append(1)
                else:
                    presence_count[instrument_presence.index(instrument)] += 1

            index = instruments_in(instr_groups, instruments)
            if index == -1:
                instruments.append(instr_groups)
                instruments_count.append(1)
            else:
                instruments_count[index] += 1

            print(folder)
            print(instr_groups)
            print('--' * 15)


        except Exception as exception:
            print(folder)
            print(exception)
            continue

    print(len(instruments))
    print(len(instrument_presence))
    edited = []
    for i in instruments:
        edited.append(', '.join(i))
    xlabel = "Amount, %"
    tit = ''
    title = "Different types of instruments"
    Plotting.make_plot_vertical(instruments_count, edited, tit, xlabel)

    # xlabel = "Amount, %"
    # title = "Instrument presence in songs"
    # Plotting.make_plot_vertical(presence_count, instrument_presence, ' ', xlabel)

# analysis_structure()
