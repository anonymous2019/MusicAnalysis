from mido import MidiFile
from BarClass import Bar

mid = MidiFile('acdc-highway_to_hell.mid')


class NewSongAnalyzer:
    # initialization
    def __init__(self, midi_path):
        self.midi = MidiFile(midi_path)
        self.name = midi_path

    # method for getting all tempos in a song
    def get_all_tempos(self):
        result = 0
        tempos = []
        tracks = self.midi.tracks
        for i in range(0, 1):
            for j in range(0, len(tracks[i])):
                if tracks[i][j].type == 'set_tempo':
                    result += 1
                    tempos.append(tracks[i][j].tempo)
        return result, tempos

    # method for getting all time signatures in a song
    def get_all_time_signatures(self):
        result = 0
        tempos = []
        tracks = self.midi.tracks
        for i in range(0, 1):
            for j in range(0, len(tracks[i])):
                if tracks[i][j].type == 'time_signature':
                    result += 1
                    num = tracks[i][j].numerator
                    denom = tracks[i][j].denominator
                    tempos.append(str(num) + "/" + str(denom))
        return result, tempos

    def tempo_converter(self, value):
        bpm = (1000000 / value) * 60
        return bpm

    # def get_first_track:
    def get_first_track(self):
        tempo = -1
        numerator = -1
        denominator = -1
        full_bar = 0

        current_bar = Bar()

        for message in self.midi.tracks[0]:

            # starting case
            if tempo == -1 or numerator == -1 or denominator == -1:
                if message.type == 'set_tempo':
                    tempo = self.tempo_converter(message.tempo)
                    current_bar.set_tempo(tempo)
                if message.type == 'time_signature':
                    numerator = message.numerator
                    denominator = message.denominator
                    current_bar.set_numerator(numerator)
                    current_bar.set_denominator(denominator)

            # if note on/off message met
            if (message.type == 'note_off' or message.type == 'note_on'):
                # TODO: here!
                note_time = message.time
                actual_note = 0
                current_bar.add_to_bar(actual_note)

            # Tempo or signature change in the middle of song
            if message.type == 'set_tempo':
                tempo = self.tempo_converter(message.tempo)
                # TODO: complete previous bar and create new

            if message.type == 'time_signature':
                numerator = message.numerator
                denominator = message.denominator
                # TODO: complete previous bar and create


sa = NewSongAnalyzer('acdc-highway_to_hell.mid')

for message in mid.tracks[0]:
    print(message)
