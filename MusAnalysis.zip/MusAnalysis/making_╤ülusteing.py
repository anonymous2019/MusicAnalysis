import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from sklearn.cluster import MeanShift, estimate_bandwidth
from sklearn.decomposition import PCA
import NoteBasedComparison as nbc


def get_features_equalities(song):
    features = []
    equalities = nbc.track_by_track_equalities(song)

    for i in range(0, len(equalities[0])):
        line = []
        for equality in equalities:
            line.append(equality[i])
        features.append(line)

    features = np.array(features)
    return features


def get_features_custom(song):
    features = []
    tracks = song.remove_bad_tracks()
    # tracks = song.tracks
    print(len(tracks))
    # for track in tracks:
    #     print(track.name)
    for i in range(0, len(tracks[0].bars)):
        line = []
        try:
            for j in range(len(tracks)):
                line.append(song.tracks[j].bars[i].note_type_ratio('single'))
                line.append(song.tracks[j].bars[i].note_type_ratio('chord'))
                # line.append(song.tracks[j].bars[i].note_type_ratio('pause'))
                # line.append(song.tracks[j].bars[i].mean_note_value())
                line.append(song.tracks[j].bars[i].mean_note_length())
                line.append(song.tracks[j].bars[i].median_note())
                # line.append(song.tracks[j].bars[i].get_min_note())
                # line.append(song.tracks[j].bars[i].get_max_note())
                # line.append(song.tracks[j].bars[i].bar_size)
                # line.append(song.tracks[j].bars[i].tempo_ticks)
            features.append(line)
        except:
            continue
    return np.array(features)


def custom_tracks_features(tracks):
    features = []

    print(len(tracks))

    for track in tracks:
        print(track.name)

    for i in range(0, len(tracks[0].bars)):
        line = []
        try:
            for j in range(len(tracks)):
                line.append(tracks[j].bars[i].note_type_ratio('single'))
                line.append(tracks[j].bars[i].note_type_ratio('chord'))
                # line.append(tracks[j].bars[i].note_type_ratio('pause'))
                # line.append(tracks[j].bars[i].mean_note_value())
                line.append(tracks[j].bars[i].mean_note_length())
                line.append(tracks[j].bars[i].median_note())
                # line.append(tracks[j].bars[i].get_min_note())
                # line.append(tracks[j].bars[i].get_max_note())
                # line.append(tracks[j].bars[i].bar_size)
                # line.append(tracks[j].bars[i].tempo_ticks)
            features.append(line)
        except:
            continue
    return np.array(features)


def get_features_custom_track(song, track_num):
    features = []

    for i in range(0, len(song.tracks[0].bars)):
        line = []

        # line.append(track.bars[i].mean_note_length())
        line.append(song.tracks[track_num].bars[i].note_type_ratio('single'))
        line.append(song.tracks[track_num].bars[i].note_type_ratio('chord'))
        line.append(song.tracks[track_num].bars[i].note_type_ratio('pause'))
        line.append(song.tracks[track_num].bars[i].mean_note_length())
        # line.append(song.tracks[j].bars[i].bar_size)
        line.append(song.tracks[track_num].bars[i].tempo_ticks)
        features.append(line)
    return np.array(features)


def get_features_raw(song):
    features = []

    for i in range(0, len(song.tracks[0].bars)):
        line = []
        for track in song.tracks:
            line.append(track.bars[i].mean_note_length())
            line.append(track.bars[i].mean_note_value())
            line.append(track.bars[i].is_pause())
        features.append(line)
    return np.array(features)


def get_features_track(song, track_number):
    features = []

    track = song.tracks[track_number]
    for i in range(0, len(track.bars)):
        line = []
        line.append(track.bars[i].mean_note_length())
        line.append(track.bars[i].mean_note_value())
        line.append(track.bars[i].is_pause())
        features.append(line)
    return np.array(features)


def do_clustering(features, clusters=5):
    features = scale(features)
    features = PCA(n_components=2).fit_transform(features)
    labels = KMeans(n_clusters=clusters, random_state=0).fit_predict(features)
    return labels


def mean_shift(features):
    features = scale(features)
    features = PCA(n_components=2).fit_transform(features)
    bandwidth = estimate_bandwidth(features, quantile=0.2, n_samples=500)
    ms = MeanShift(bandwidth=bandwidth, bin_seeding=True)
    labels = ms.fit_predict(features)
    return labels
