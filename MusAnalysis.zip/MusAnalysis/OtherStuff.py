from Playground import *
from combinator import Combinator
import mido as md

parts = ['intro', 'verse', 'pre_chorus', 'chorus', 'bridge', 'middle_eight', 'solo', 'outro']


def check_if_in(list, combinator):
    for i in range(len(list)):
        if combinator.is_same(list[i]):
            return i
    return -1


def get_parts(dataset_line, part):
    result = []
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == part + ':':
            result = dataset_line[i + 1].split(',')
            break

    if result == []:
        return [-1]
    # if ',' in result:
    #     result = result.split(',')
    blocks = []
    for i in result:
        diap = i.split('-')
        for j in range(int(diap[0]) - 1, int(diap[1])):
            blocks.append(j)
    return blocks


def position_to_part(line, position):

    for part in parts:
        bars = get_parts(line, part)
        if position in bars:

            return part


def get_structure(dataset_line, numbered=True):
    result = list()
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == 'structure:':
            result = dataset_line[i + 1]
    structure = list()
    if numbered:
        vc = 0
        cc = 0
        sc = 0
        mc = 0
        bc = 0
        pc = 0
        for i in result:
            if i == 'i':
                structure.append('intro')
            if i == 'v':
                structure.append('verse' + str(vc))
                vc += 1
            if i == 'b':
                structure.append('bridge' + str(bc))
                bc += 1
            if i == 'p':
                structure.append('pre_chorus' + str(bc))
                pc += 1
            if i == 'c':
                structure.append('chorus' + str(cc))
                cc += 1
            if i == 's':
                structure.append('solo' + str(sc))
                sc += 1
            if i == 'o':
                structure.append('outro')
            if i == 'm':
                structure.append('middle_eight' + str(mc))
                mc += 1
    else:
        for i in result:
            if i == 'i':
                structure.append('intro')
            if i == 'v':
                structure.append('verse')
            if i == 'b':
                structure.append('bridge')
            if i == 'p':
                structure.append('pre_chorus')
            if i == 'c':
                structure.append('chorus')
            if i == 's':
                structure.append('solo')
            if i == 'o':
                structure.append('outro')
            if i == 'm':
                structure.append('middle_eight')
    return structure


def analysis_ts():
    path = '~/Desktop/MusAnalysis/AllHard'

    fixed_ts = list()
    fixed_count = list()

    changes_number = list()
    changes_number_amount = list()

    types_of_changes = list()
    toc_amount = list()

    for folder in os.listdir(os.path.expanduser(path)):
        try:

            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            structure = list()  # structure is here
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    structure = get_structure(line)
                    f.close()
                    break

            f.close()

            # do signature/tempo stuff
            # tempo stuff
            song = fill_song(os.path.expanduser(npath))
            changes = song.get_ts_change_count()

            # collecting number of changes...
            if changes not in changes_number:
                changes_number.append(changes)
                changes_number_amount.append(1)
            else:
                changes_number_amount[changes_number.index(changes)] += 1

            # if there are no changes
            if changes == 0:
                ts = song.get_ts()[0]
                if ts not in fixed_ts:
                    fixed_ts.append(ts)
                    fixed_count.append(1)
                else:
                    fixed_count[fixed_ts.index(ts)] += 1

            # if changes exist
            else:
                positions, values = song.get_ts_switch_positions()
                for i in range(len(positions)):
                    to_add = Combinator(
                        [position_to_part(line, positions[i][0]), position_to_part(line, positions[i][1])])
                    value = [values[i][0], values[i][1]]
                    index = check_if_in(types_of_changes, to_add)
                    if index == -1:
                        to_add.add(value)
                        types_of_changes.append(to_add)
                        toc_amount.append(1)

                    else:
                        types_of_changes[index].add(value)
                        toc_amount[index] += 1

            print(folder)
            # # if folder == 'aerosmith-livin_on_the_edge.mid':
            # #     print(changes)
            # #     print(positions)
            # #     print(values)
            # print(types_of_changes)
            # print(toc_amount)
            # print(fixed_tempo)
            # print(fixed_count)
            # print(changes_number)
            # print(changes_number_amount)
            # print('--' * 10)

            continue



        except Exception as exception:
            print(folder)
            print(line)
            print(exception)
            continue

    # xlabel = "Amount, %"
    # tit = ''
    # title = "Time Signature in songs with fixed Time Signature"
    # percents = []
    # total = sum(fixed_count)
    # for i in fixed_count:
    #     percents.append(i / total * 100)
    # fixed_ts, percents = (list(t) for t in zip(*sorted(zip(fixed_ts, percents))))
    # Plotting.make_plot_vertical(percents, fixed_ts, tit, xlabel)
    #
    # xlabel = "Amount, %"
    # tit = ''
    # title = "Changes of Time Signature"
    #
    # percents = []
    # total = sum(changes_number_amount)
    # for i in changes_number_amount:
    #     percents.append(i / total * 100)
    # changes_number, percents = (list(t) for t in zip(*sorted(zip(changes_number,percents))))
    # Plotting.make_plot_vertical(percents, changes_number, tit, xlabel)

    # xlabel = "Amount, %"
    # title = "Tempo change places"
    #
    # types_pure = list()
    # for i in types_of_changes:
    #     types_pure.append(i.main)
    # percents = []
    # total = sum(toc_amount)
    # for i in toc_amount:
    #     percents.append(i / total * 100)
    # types_pure, percents = (list(t) for t in zip(*sorted(zip(types_pure, percents))))
    # Plotting.make_plot_vertical(percents, types_pure, '', xlabel)

    xlabel = "Amount, %"
    title = "TS change places"

    types_pure = list()
    for i in types_of_changes:
        types_pure.append(' '.join(i.main))
    percents = []
    total = sum(toc_amount)
    for i in toc_amount:
        percents.append(i / total * 100)

    types_pure, percents = (list(t) for t in zip(*sorted(zip(types_pure, percents))))
    Plotting.make_plot_vertical(percents, types_pure, title, xlabel, save=True)



    # percents = []
    # total = sum(changes_number_amount)
    # for i in changes_number_amount:
    #     percents.append(i / total * 100)
    # print(changes_number)
    # print(percents)
    # changes_number, percents = (list(t) for t in zip(*sorted(zip(changes_number, percents))))
    # Plotting.make_plot_vertical(percents, changes_number, tit, xlabel)

    # xlabel = "Count"
    # title = "Tempo change places"
    #
    # types_pure = list()
    # for i in types_of_changes:
    #     types_pure.append(i.main)
    # Plotting.make_plot_vertical(toc_amount, types_pure, title, xlabel)



    # for i in types_of_changes:
    #     try:
    #         xlabel = "Amount, %"
    #         title = "The values of " + str(' '.join(i.main)) + " changes in songs"
    #         amounts_percents = i.get_amounts_percents()
    #         children = i.get_children()
    #         print(amounts_percents)
    #         print(children)
    #         amounts_percents, children = (list(t) for t in zip(*sorted(zip(amounts_percents, children))))
    #         Plotting.make_plot_vertical(amounts_percents, children, '', xlabel, save=True, name=title)
    #     except:
    #         print(i.main)
    #         print(i.get_children)

def analysis_tempo():
    path = '~/Desktop/MusAnalysis/AllHard'

    fixed_tempo = list()
    fixed_count = list()

    changes_number = list()
    changes_number_amount = list()

    types_of_changes = list()
    toc_amount = list()

    for folder in os.listdir(os.path.expanduser(path)):
        try:

            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            structure = list()  # structure is here
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    structure = get_structure(line)
                    f.close()
                    break

            f.close()

            # do signature/tempo stuff
            # tempo stuff
            song = fill_song(os.path.expanduser(npath))
            changes = song.get_tempos_change_count()

            # collecting number of changes...
            if changes not in changes_number:
                changes_number.append(changes)
                changes_number_amount.append(1)
            else:
                changes_number_amount[changes_number.index(changes)] += 1

            # if there are no changes
            if changes == 0:
                bpm = song.get_tempos()[0]
                tempo = md.bpm2tempo(bpm)
                if tempo not in fixed_tempo:
                    fixed_tempo.append(tempo)
                    fixed_count.append(1)
                else:
                    fixed_count[fixed_tempo.index(tempo)] += 1

            # if changes exist
            else:
                positions, values = song.get_tempo_switch_positions()
                for i in range(len(positions)):
                    to_add = Combinator(
                        [position_to_part(line, positions[i][0]), position_to_part(line, positions[i][1])])
                    value = [md.bpm2tempo(values[i][0]), md.bpm2tempo(values[i][1])]
                    index = check_if_in(types_of_changes, to_add)
                    if index == -1:
                        to_add.add(value)
                        types_of_changes.append(to_add)
                        toc_amount.append(1)

                    else:
                        types_of_changes[index].add(value)
                        toc_amount[index] += 1

            print(folder)
            # # if folder == 'aerosmith-livin_on_the_edge.mid':
            # #     print(changes)
            # #     print(positions)
            # #     print(values)
            # print(types_of_changes)
            # print(toc_amount)
            # print(fixed_tempo)
            # print(fixed_count)
            # print(changes_number)
            # print(changes_number_amount)
            # print('--' * 10)

            continue



        except Exception as exception:
            print(folder)
            print(line)
            print(exception)
            continue
    #
    # xlabel = "Amount, %"
    # title = "Tempos in songs with fixed tempo"
    # tit = ''
    # percents = []
    # total = sum(fixed_count)
    # for i in fixed_count:
    #     percents.append(i / total * 100)
    # fixed_tempo, percents  = (list(t) for t in zip(*sorted(zip(fixed_tempo, percents))))
    # Plotting.make_plot_vertical(percents, fixed_tempo, tit, xlabel)
    #
    # xlabel = "Amount, %"
    # title = "Changes of tempos"
    # tit = ''
    # percents = []
    # total = sum(changes_number_amount)
    # for i in changes_number_amount:
    #     percents.append(i / total * 100)
    # changes_number, percents = (list(t) for t in zip(*sorted(zip(changes_number, percents))))
    # Plotting.make_plot_vertical(percents, changes_number, tit, xlabel)


    xlabel = "Amount, %"
    title = "Tempo change places"

    types_pure = list()
    for i in types_of_changes:
        types_pure.append(' '.join(i.main))
    percents = []
    total = sum(toc_amount)
    for i in toc_amount:
        percents.append(i / total * 100)

    types_pure, percents = (list(t) for t in zip(*sorted(zip(types_pure, percents))))
    Plotting.make_plot_vertical(percents, types_pure, title, xlabel, save=True)

    # percents = []
    # total = sum(changes_number_amount)
    # for i in changes_number_amount:
    #     percents.append(i / total * 100)
    # changes_number, percents = (list(t) for t in zip(*sorted(zip(changes_number, percents))))
    # Plotting.make_plot_vertical(percents, changes_number, tit, xlabel)

    # for i in types_of_changes:
    #     try:
    #         xlabel = "Amount, %"
    #         title = "The values of " + str(' '.join(i.main)) + " changes in songs"
    #         amounts_percents = i.get_amounts_percents()
    #         children = i.get_children()
    #         print(amounts_percents)
    #         print(children)
    #         amounts_percents, children = (list(t) for t in zip(*sorted(zip(amounts_percents, children))))
    #         Plotting.make_plot_vertical(amounts_percents, children, '', xlabel, save=True, name=title)
    #     except:
    #         print(i.main)
    #         print(i.get_children)


analysis_tempo()
