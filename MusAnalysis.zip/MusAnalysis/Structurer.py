from BarClass import Bar
from Filling import fill_song
from Song import Song
from Track import Track
from collections import Counter
import copy


def get_bar_equality_test(bar_1, bar_2):
    equality = 1

    lengths1 = bar_1.lengths
    lengths2 = bar_2.lengths

    sum1 = 0
    for i in range(0, len(lengths1)):

        sum1 += lengths1[i]
        matched = False
        sum2 = 0

        for j in range(0, len(lengths2)):
            sum2 += lengths2[j]
            if sum1 == sum2 and lengths1[i] == lengths2[j]:
                matched = True
                break

        if not matched:
            equality -= lengths1[i]

    return equality


def get_bar_equality(bar_1, bar_2):
    equality = 1

    if len(bar_1.lengths) == len(bar_2.lengths):
        length = len(bar_1.lengths)
        for i in range(0, length):
            if bar_1.lengths[i] != bar_2.lengths[i]:
                equality -= 1. / length
        return equality

    else:
        sum1 = 0
        sum2 = 0
        i = 0
        j = 0
        end = False

        sum1 += bar_1.lengths[0]
        sum2 += bar_2.lengths[0]

        while not end:
            try:
                if i >= len(bar_1.lengths) - 1 or j >= len(bar_2.lengths) - 1:
                    end = True
                    continue

                if is_approximately_equal(sum1, sum2, 0.01):
                    i += 1
                    j += 1
                    sum1 += bar_1.lengths[i]
                    sum2 += bar_2.lengths[j]

                if round(sum1, 2) < round(sum2, 2) and i < len(bar_1.lengths) - 1:
                    equality -= bar_1.lengths[i]
                    while sum1 < sum2 - 0.01:
                        i += 1
                        sum1 += bar_1.lengths[i]
                        equality -= bar_1.lengths[i]

                if round(sum1, 2) > round(sum2, 2):
                    equality -= bar_2.lengths[j]
                    while sum1 - 0.01 > sum2 and j < len(bar_2.lengths) - 1:
                        j += 1
                        sum2 += bar_2.lengths[j]
                        equality -= bar_2.lengths[j]

            except:
                print("oops")
                equality = 0
        return round(equality, 2)


def is_approximately_equal(a, b, coefficient):
    if b - coefficient <= a <= b + coefficient:
        return True
    return False


def get_global_equality(tracks, i, j):
    bars1 = []
    bars2 = []
    decrease = 0

    for track in tracks:
        bars1.append(track.bars[i])
        bars2.append(track.bars[j])

        if track.bars[i].notes == [0] and track.bars[j].notes == [0]:
            decrease += 1

    equality = 0
    track_number = len(bars1)
    for i in range(0, track_number):
        # TODO: test!!!
        difference = get_bar_equality_test(bars1[i], bars2[i])
        equality += difference
        # print("track - " + str(i) + " " + str(difference))
        # if decrease > 0:
        # print("decreasing = " + str(decrease))
    return equality / track_number


def get_structure_single(song):
    size = len(song.tracks[0].bars)
    positions = []
    groups = []
    p = 1

    for i in range(0, size):
        positions.append(0)

    for i in range(0, size):
        if positions[i] != 0:
            continue

        if positions[i] == 0:
            if p not in groups:
                positions[i] = p
                groups.append(p)
                p += 1

        for j in range(i + 1, size):
            if song.tracks[0].bars[i].bar_size == song.tracks[0].bars[j].bar_size:
                if get_global_equality(song.tracks, i, j) >= 0.8 and positions[j] == 0:
                    positions[j] = p

    # getting rid of short parts
    # TODO: dont forget to clear all stuff for debuging

    repeatings = Counter(positions)

    current = positions[0]
    steps = 1
    structure = []
    for i in range(1, len(positions)):
        if current != positions[i]:
            structure.append([current, steps])
            steps = 1
            current = positions[i]
            continue
        if current == positions[i]:
            steps += 1
            continue
    structure.append([current, steps])

    str = copy.deepcopy(structure)

    final = []
    for i in range(0, len(structure)):
        if i + 1 >= len(structure) - 1 and structure[i][1] < 2:
            final[len(final) - 1][1] += structure[i][1]
            break
        if structure[i][1] < 2:
            structure[i + 1][1] += structure[i][1]
        if structure[i][1] >= 2:
            final.append(structure[i])

    return positions, str, final


# ----------------

# midi = 'deep_purple-perfect_strangers.mid'
# midi = "Dragonforce - Through the Fire and Flames (Version 1).mid"
# midi = 'acdc-highway_to_hell.mid'

# test_song = fill_song(midi)
# print(test_song.tracks[3].bars[15].lengths)
# print(test_song.tracks[3].bars[16].lengths)
# equality = get_bar_equality_test(test_song.tracks[3].bars[15], test_song.tracks[3].bars[16])
# print("test: " + str(equality))
#
# result, structure, final = get_structure_single(test_song)
# equality = get_global_equality(test_song.tracks, 0, 1)
# print(equality)
# #
# print("-----------------------------------")
# print(result)
# print("-----------------------------------")
# print(structure)
# print("-----------------------------------")
# print(final)
#
# c = 1
# for i in range(0, len(final)):
#     for j in range(0, final[i][1]):
#         print("bar " + str(c) + " --- " + str(final[i][0]))
#         c += 1



# bar_1 = Bar()
# bar_1.set_lengths([0.75, 0.125, 0.125])
# bar_2 = Bar()
# bar_2.set_lengths([0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125])
#
# bar_11 = Bar()
# bar_11.set_lengths([0.16, 0.33, 0.33, 0.16])
# bar_22 = Bar()
# bar_22.set_lengths([0.16, 0.16, 0.16, 0.083, 0.083, 0.33])
#
# print(get_bar_equality(bar_1, bar_2))
# print(is_approximately_equal(0.33, 0.338, 0.01))
# print(get_bar_equality(bar_11, bar_22))
#
# bars1 = []
# bars1.append(bar_1)
# bars1.append(bar_11)
# bars2 = []
# bars2.append(bar_2)
# bars2.append(bar_22)

# print(get_global_equality(bars1, bars2))
