import numpy as np
from collections import defaultdict
import operator


def bar_equality(bar_1, bar_2):
    notes1 = bar_1.transformed_notes
    notes2 = bar_2.transformed_notes

    equality = 0
    length = len(notes1)
    for i in range(0, length):
        try:
            if notes1[i] == notes2[i]:
                equality += 1 / length
        except:
            continue

    return equality


def all_song(song, threshold=0.75):
    tracks = song.remove_bad_tracks()
    track_num = len(tracks)
    size = len(tracks[0].bars)
    positions = [0] * size

    p = 1

    for i in range(0, size):

        if positions[i] != 0:
            continue

        if positions[i] == 0:
            positions[i] = p

            for j in range(i + 1, size):
                equality = 1

                if positions[j] == 0:
                    for track in tracks:
                        try:
                            if track.bars[i].bar_size == track.bars[j].bar_size \
                                    and bar_equality_test(track.bars[i], track.bars[j]) >= threshold:
                                continue
                            else:
                                equality -= 1 / track_num
                        except:
                            continue
                    if equality > 0.75:
                        positions[j] = p
            p += 1

    return positions


def bar_equality_test(bar_1, bar_2):
    notes1 = bar_1.transformed_notes
    notes2 = bar_2.transformed_notes

    equality = 0
    length = len(notes1)
    difference = 0
    for i in range(0, length):
        try:
            if notes1[i] == notes2[i]:
                equality += 1
            else:
                difference += 1
        except:
            continue

    return (equality * 2) / (length + difference)


def one_track_equality(track, threshold=0.75):
    size = len(track.bars)
    positions = [0] * size
    p = 1

    for i in range(0, size):

        if positions[i] != 0:
            continue

        if positions[i] == 0:
            positions[i] = p

            for j in range(i + 1, size):
                if track.bars[i].bar_size == track.bars[j].bar_size \
                        and bar_equality(track.bars[i], track.bars[j]) >= threshold \
                        and positions[j] == 0:
                    positions[j] = p
            p += 1

    return positions


def one_track_equality_test(track, threshold=1.5):
    size = len(track.bars)
    positions = [0] * size
    p = 1

    for i in range(0, size):

        if positions[i] != 0:
            continue

        if positions[i] == 0:
            positions[i] = p

            for j in range(i + 1, size):
                if track.bars[i].bar_size == track.bars[j].bar_size \
                        and bar_equality_test(track.bars[i], track.bars[j]) >= threshold \
                        and positions[j] == 0:
                    positions[j] = p
            p += 1

    return positions


def track_by_track_equalities(song):
    equalities = []
    for track in song.tracks:
        equalities.append(one_track_equality(track))
    return equalities


def make_n_classes(track, n=2, threshold=2):
    unique = 10000
    structure = []
    while unique != n:
        structure = one_track_equality_test(track, threshold)
        unique = len(np.unique(structure))
        if unique < n:
            threshold += threshold / 2
        if unique > n:
            threshold -= threshold / 2
    return structure


def is_monotonous(track):
    equalities = sorted(one_track_equality(track))
    i = 0
    length = len(equalities)
    current = equalities[0]
    for bar in equalities:
        if i > length * 0.6:
            return True

        if bar == current:
            i += 1
        else:
            current = bar
            i = 1

    return False


def make_magic_pls(equalities):
    couples = defaultdict(int)
    result = [0] * len(equalities)
    for i in range(0, len(equalities) - 1):
        if equalities[i] == equalities[i+1]:
            continue
        couple = tuple(sorted([equalities[i], equalities[i + 1]]))
        if couple not in couples:
            couples[couple] = 1
        else:
            couples[couple] += 1

    sorted_couples = sorted(couples.items(), key=operator.itemgetter(1), reverse=True)
    print(sorted_couples)

# midi = 'deep_purple-perfect_strangers.mid'
# midi = "Dragonforce - Through the Fire and Flames (Version 1).mid"
# midi = 'acdc-highway_to_hell.mid'
#
# test_song = fill_song(midi)
# structure = make_n_classes(test_song.tracks[0], 4, 0.8)
# draw_simple(structure)



# structure = one_track_equality(test_song.tracks[0])
# print(structure)
#
# print("--------")
# for i in range(0, len(structure)):
#     print(str(i + 1) + " " + str(structure[i]))

# -----------
# bar1 = test_song.tracks[0].bars[0]
# bar2 = test_song.tracks[0].bars[2]
#
# print(bar1.transformed_notes)
# print(bar2.transformed_notes)
#
# for length in bar1.lengths:
#     print(length)
#
# for length in bar2.lengths:
#     print(length)
#
# print(bar_equality(bar1, bar2))
