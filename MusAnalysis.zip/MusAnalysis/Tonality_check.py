import copy

cmaj = [0, 2, 4, 5, 7, 9, 11]
сshmaj = [0, 1, 3, 5, 6, 8, 10]
dmaj = [1, 2, 4, 6, 7, 9, 11]
dshmaj = [0, 2, 3, 5, 7, 8, 10]
emaj = [1, 3, 4, 6, 8, 9, 11]
fmaj = [0, 2, 4, 5, 7, 9, 10]
fshmaj = [1, 3, 5, 6, 8, 10, 11]
gmaj = [0, 2, 4, 6, 7, 9, 11]
gshmaj = [0, 1, 3, 5, 7, 8, 10]
amaj = [1, 2, 4, 6, 8, 9, 11]
ashmaj = [0, 2, 3, 5, 7, 9, 10]
bmaj = [1, 3, 4, 6, 8, 10, 11]

tonalities = [cmaj, сshmaj, dmaj, dshmaj, emaj, fmaj, fshmaj, gmaj, gshmaj, amaj, ashmaj, bmaj]
notes = ['C', 'C#', 'D', 'E#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


def note_to_string(note, octave=False):
    name = notes[note % 12]
    if octave:
        name += " " + str(note // 12) + " octave"
    return name


def minor_tonalities(note):
    result = []
    i = 0
    j = note
    result.append(note)
    while j < note + 10:
        if i == 1 or i == 4:
            j += 1
            i += 1
            result.append(j % 12)
        else:
            j += 2
            i += 1
            result.append(j % 12)
    result.sort()
    return result


def major_tonalities(note):
    result = []
    i = 0
    j = note
    result.append(note)
    while j < note + 10:
        if i == 2 or i == 6:
            j += 1
            i += 1
            result.append(j % 12)
        else:
            j += 2
            i += 1
            result.append(j % 12)
    result.sort()
    return result


def find_tonality(notes):
    candidates = copy.deepcopy(tonalities)
    if notes == [-1]:
        return [-1]
    for note in notes:
        i = 0
        while i < len(candidates):
            if note not in candidates[i]:
                candidates.remove(candidates[i])
            else:
                i += 1
    if candidates == []:
        print("hey! " + str(notes))
    return candidates


def track_tonalities(track):
    result = []
    for bar in track.bars:
        result.append(find_tonality(bar.pure_notes()))
    return result


def all_tonalities(bar_tonalities):
    places = []
    marked = []
    result = []

    for i in range(0, len(bar_tonalities)):
        marked.append(0)
        result.append([])

    for i in range(0, len(bar_tonalities)):

        if marked[i] == 1:
            continue

        current_main = copy.deepcopy(bar_tonalities[i])
        places.append(i)

        for j in range(i + 1, len(bar_tonalities)):
            if j == 85:
                print('a')
            if marked[j] == 1:
                continue

            h = 0
            current = copy.deepcopy(current_main)
            while h < len(current):
                if current[h] not in bar_tonalities[j]:
                    current.remove(current[h])
                h += 1

            if len(current) > 0:
                current_main = copy.deepcopy(current)
                places.append(j)

        for j in places:
            result[j] = current_main
            marked[j] = 1

        places = []

    return result
