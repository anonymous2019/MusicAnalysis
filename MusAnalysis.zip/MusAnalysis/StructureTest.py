import copy
from Analyse import SongAnalyzer


class StructureFinder:
    def __init__(self, song_analyzer, track = -1):
        self.song_analyzer = song_analyzer
        if track == -1:
            self.song = song_analyzer.get_all_tracks()
        else:
            self.song = []
            self.song.append(song_analyzer.get_one_track(track))

    def get_song_part(self, index, length):
        result = []
        for track in self.song:
            cut = []
            for i in range(index, index + length):
                cut.append(track[i])
            result.append(cut)
        return result

    def compare_tracks(self, part1, part2):
        length1 = len(part1)
        length2 = len(part2)
        if length1 == length2:
            param = 1
            for i in range(0, length1):
                if part1[i] != part2[i]:
                    param -= 1 / length1
            return param
        else:
            return 0

    def compare_beats(self, part1, part2):
        length = len(part1)
        result = length
        for i in range(0, length):
            result -= (1 - self.compare_tracks(part1[i], part2[i]))
        return result / length

    def compare(self, part1, part2):
        length = len(part1)
        result = length
        for i in range(0, length):
            result -= (1 - self.compare_beats(part1[i], part2[i]))
        return result / length

    def find_all_equal_parts(self, lnth=1):
        copies = []
        length = len(self.song[1])
        for i in range(0, length):
            for j in range(1, 1 + lnth):
                try:
                    part1 = self.get_song_part(self.song, i, j)

                    for k in range(i + j, length - j + 1):
                        part2 = self.get_song_part(self.song, k, j)
                        if self.compare(part1, part2) >= 0.75:
                            copies.append([[i, i + j], [k, k + j]])
                except:
                    continue
        return copies

    def new_fep(self, lnth):
        copies = []
        length = len(self.song[0])
        found = False
        for i in range(0, length):
            try:
                found = False
                part1 = self.get_song_part(i, lnth)

                for k in range(0, length - lnth):
                    part2 = self.get_song_part(k, lnth)
                    if self.compare(part1, part2) >= 0.8:
                        copies.append([[i, i + lnth], [k, k + lnth]])
                        found = True

                if not found:
                    copies.append([[i, i + lnth], [i, i + lnth]])
            except:
                continue
        return copies

    def structure(self, ep_list):
        result = [[]]
        for elem in ep_list:
            done = False
            for part in result:
                if elem[0] in part and not elem[1] in part:
                    part.append(elem[1])
                    done = True
                if elem[1] in part and not elem[0] in part:
                    part.append(elem[0])
                    done = True
                if elem[1] in part and elem[0] in part:
                    done = True
            if not done:
                result.append([elem[0], elem[1]])
        result.remove([])
        return result

    def remove_copies(self, str_list):
        result = copy.deepcopy(str_list)
        for i in range(0, len(str_list)):
            for j in range(i + 1, len(str_list)):
                if i!= j:
                    for elem in str_list[i]:
                        for _elem in str_list[j]:
                            if elem == _elem:
                                try:
                                    result.remove(str_list[j])
                                    break
                                except:
                                    continue
        return result

    def new_structure(self, ep_list):
        result = []
        result.append(ep_list[0])
        for i in range(1, len(ep_list)):
            for elem in result:
                if ep_list[i][0] in elem and ep_list[i][1] not in elem:
                    elem.append(ep_list[i][1])
                    break
                if ep_list[i][0] not in elem and ep_list[i][1] in elem:
                    elem.append(ep_list[i][0])
                    break
                if ep_list[i][0] in elem and ep_list[i][1] in elem:
                    break
                if ep_list[i][0] not in elem and ep_list[i][1] not in elem:
                    result.append(ep_list[i])
        return result

    def to_dict(self, length):
        list = []
        struct = self.get_data(length)
        for i in range(0, len(struct)):
            for elem in struct[i]:
                start = elem[0]
                finish = elem[1]
                add = dict(track=i, start=start, finish=finish)
                if add not in list:
                    list.append(add)
        return list

    def get_data(self, length):
        return self.remove_copies(self.structure(self.new_fep(length)))

    def get_part_number(self, length):
        return len(self.remove_copies(self.structure(self.new_fep(length))))


sa = SongAnalyzer('acdc-highway_to_hell.mid')
sf = StructureFinder(sa, 1)

# print(sf.new_fep(4))
# stuff = sf.remove_copies(sf.structure(sf.new_fep(2)))
# print(stuff)

