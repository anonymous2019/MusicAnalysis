import NoteBasedComparison as nbc


class Song:
    def __init__(self, name):
        self.name = name
        self.tracks = []

    def add_track(self, track):
        self.tracks.append(track)

    def t_change_plot(self):
        result = []
        for i in self.tracks[0].bars:
            result.append(i.tempo_ticks / 100000)
        return result

    def ts_change_plot(self):
        result = []
        for i in self.tracks[0].bars:
            result.append(i.numerator)
        return result

    def remove_bad_tracks(self):
        result = []
        for track in self.tracks:
            if track.get_emptiness() < 0.5 and not nbc.is_monotonous(track):
                result.append(track)
                print(track.name)
        return result

    def get_tempos_change_count(self):
        changes = 0
        current = self.tracks[0].bars[0].tempo_ticks
        for bar in self.tracks[0].bars:
            if bar.tempo_ticks != current:
                changes += 1
                current = bar.tempo_ticks
        return changes

    def get_ts_change_count(self):
        changes = 0
        current = str(self.tracks[0].bars[0].numerator) + '/' + str(self.tracks[0].bars[0].denominator)
        for bar in self.tracks[0].bars:
            if str(bar.numerator) + '/' + str(bar.denominator) != current:
                changes += 1
                current = str(bar.numerator) + '/' + str(bar.denominator)
        return changes

    def get_tempos(self):
        tempos = []
        for bar in self.tracks[0].bars:
            if bar.tempo_ticks not in tempos:
                tempos.append(bar.tempo_ticks)
        return tempos

    def get_ts(self):
        ts = []
        for bar in self.tracks[0].bars:
            if str(bar.numerator) + '/' + str(bar.denominator) not in ts:
                ts.append(str(bar.numerator) + '/' + str(bar.denominator))
        return ts

    def get_tempo_switch_positions(self):
        switches = list()
        values = list()
        current = self.tracks[0].bars[0].tempo_ticks
        for i in range(1, len(self.tracks[0].bars)):
            if self.tracks[0].bars[i].tempo_ticks != current:
                switches.append([i - 1, i])
                values.append([self.tracks[0].bars[i - 1].tempo_ticks, self.tracks[0].bars[i].tempo_ticks])
                current = self.tracks[0].bars[i].tempo_ticks
        return switches, values

    def get_ts_switch_positions(self):
        switches = list()
        values = list()
        current = str(self.tracks[0].bars[0].numerator) + '/' + str(self.tracks[0].bars[0].denominator)
        for i in range(1, len(self.tracks[0].bars)):
            new = str(self.tracks[0].bars[i].numerator) + '/' + str(self.tracks[0].bars[i].denominator)
            if new != current:
                switches.append([i - 1, i])
                values.append([current, new])
                current = new
        return switches, values

    def get_instruments(self):
        result = []
        for track in self.tracks:
            if not track.get_emptiness() > 0.95:
                result.append(track.midi_program)
        return result

    def get_ith_bar_name(self, i):
        result = ''
        bar = self.tracks[0].bars[i]
        result += (str(bar.numerator) + '.' + str(bar.denominator))

        for track in self.tracks:
            result += program_to_group(track.midi_program) + " "
        return result

    def get_ith_bar_rhythm(self, i):
        result = []
        for track in self.tracks:
            result.append(track.bars[i].lengths)
        return result

    def get_all_bars_rhythms(self):
        names = []
        rhythms = []
        for i in range(0, len(self.tracks[0].bars)):
            names.append(self.get_ith_bar_name(i))
            rhythms.append(self.get_ith_bar_rhythm(i))
        return names, rhythms


def program_to_group(midi_prigram):
    if 1 <= midi_prigram <= 8:
        return 'P'  # 'Piano'
    if 9 <= midi_prigram <= 16:
        return 'CP'  # 'Chromatic Percussion'
    if 17 <= midi_prigram <= 24:
        return 'O'  # 'Organ'
    if 25 <= midi_prigram <= 32:
        return 'G'  # 'Guitar'
    if 33 <= midi_prigram <= 40:
        return 'B'  # 'Bass'
    if 41 <= midi_prigram <= 48:
        return 'S'  # 'Strings'
    if 49 <= midi_prigram <= 56:
        return 'E'  # 'Ensemble'
    if 57 <= midi_prigram <= 64:
        return 'BR'  # 'Brass'
    if 65 <= midi_prigram <= 72:
        return 'R'  # 'Reed'
    if 73 <= midi_prigram <= 80:
        return 'P'  # 'Pipe'
    if 81 <= midi_prigram <= 88:
        return 'Sl'  # 'Synth Lead'
    if 89 <= midi_prigram <= 96:
        return 'SP'  # 'Synth Pad'
    if 97 <= midi_prigram <= 104:
        return 'SE'  # 'Synth Effects'
    if 105 <= midi_prigram <= 112:
        return 'ETH'  # 'Ethnic'
    else:
        return 'D'  # 'Drums'