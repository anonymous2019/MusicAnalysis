

from mido import MidiFile
from BarClass import Bar
from Song import Song
from Track import Track


def get_song_data(filename):
    midi = MidiFile(filename)
    song = Song(filename)

    for midi_track in midi.tracks:
        new_track = Track(midi_track.name, 0)
        for message in midi_track:
            if message.type == "program_change":
                new_track.set_midi_program(message.program)
        song.add_track(new_track)

    return song


def fill_first_track(filename):
    midi = MidiFile(filename)

    # bc = 0
    tempo = 0
    numerator = 0
    denominator = 0
    current_note_block = []

    current_bar = Bar()
    track = Track()

    for message in midi.tracks[0]:

        if current_bar.get_remaining_length() <= 0.01:
            current_bar.transform_notes()
            track.addBar(current_bar)
            current_bar = Bar(tempo, numerator, denominator)
            # bc += 1
            # current_note_block = []

        # in case of messages before note_off
        if message.type != "note_off" and message.type != "note_on" and message.time > 0 and len(
                current_note_block) > 0:
            length = calculate_note_size(message.time, midi.ticks_per_beat)

            current_bar.add_to_lengths(length)
            current_bar.add_to_notes(current_note_block)

            if message.type == "time_signature":
                numerator = message.numerator
                denominator = message.denominator

            if message.type == "set_tempo":
                tempo = message.tempo

            continue

            # in case of pause
        if message.type != "note_off" and message.time > 0 and len(current_note_block) == 0:

            length = calculate_note_size(message.time, midi.ticks_per_beat)

            # if pause's length is > remaining
            while length >= current_bar.get_remaining_length():
                length -= current_bar.get_remaining_length()
                current_bar.add_to_lengths(current_bar.get_remaining_length())
                current_bar.add_to_notes(0)

                if current_bar.get_remaining_length() <= 0.01:
                    current_bar.transform_notes()
                    track.addBar(current_bar)
                    current_bar = Bar(tempo, numerator, denominator)

            # if not
            if length > 0 and current_bar.get_remaining_length() > 0:
                current_bar.add_to_lengths(length)
                current_bar.add_to_notes(0)

        if message.type == "time_signature":
            numerator = message.numerator
            denominator = message.denominator
            current_bar.set_numerator(numerator)
            current_bar.set_denominator(denominator)

        if message.type == "set_tempo":
            tempo = message.tempo
            current_bar.set_tempo(tempo)

        if message.type == "note_on":
            current_note_block.append(message.note)

        # in case of note
        if message.type == "note_off" and message.time > 0:
            length = calculate_note_size(message.time, midi.ticks_per_beat)
            current_bar.add_to_lengths(length)
            current_bar.add_to_notes(current_note_block)
            current_note_block = []

    return track


def fill_nth_track(filename, n, first_track):
    midi = MidiFile(filename)
    miditrack = midi.tracks[n]

    track = Track()
    current_note_block = []
    current_bar = Bar()
    bar_counter = 0
    current_bar.set_tempo(first_track.bars[0].tempo_ticks)
    current_bar.set_numerator(first_track.bars[0].numerator)
    current_bar.set_denominator(first_track.bars[0].denominator)

    for message in miditrack:

        # if bar is full
        if current_bar.get_remaining_length() <= 0.01:
            current_bar.transform_notes()
            track.addBar(current_bar)
            if bar_counter < len(first_track.bars) - 1:
                bar_counter += 1
                # print(bar_counter)
            current_bar = Bar(first_track.bars[bar_counter].tempo_ticks,
                              first_track.bars[bar_counter].numerator,
                              first_track.bars[bar_counter].denominator)
            # current_note_block = []

        # in case of pause
        if message.type != "note_off" and message.time > 0 and len(current_note_block) == 0:

            length = calculate_note_size(message.time, midi.ticks_per_beat)

            # if pause's length is > remaining
            while length > current_bar.get_remaining_length():
                length -= current_bar.get_remaining_length()
                current_bar.add_to_lengths(current_bar.get_remaining_length())
                current_bar.add_to_notes(0)

                if current_bar.get_remaining_length() <= 0.01:
                    current_bar.transform_notes()
                    track.addBar(current_bar)
                    if bar_counter < len(first_track.bars) - 1:
                        bar_counter += 1

                    current_bar = Bar(first_track.bars[bar_counter].tempo_ticks,
                                      first_track.bars[bar_counter].numerator,
                                      first_track.bars[bar_counter].denominator)
                    current_note_block = []

            # if not
            current_bar.add_to_lengths(length)
            current_bar.add_to_notes(0)

        if message.type == "note_on":
            current_note_block.append(message.note)

        # in case of note
        if message.type == "note_off" and message.time > 0:
            length = calculate_note_size(message.time, midi.ticks_per_beat)
            current_bar.add_to_lengths(length)
            current_bar.add_to_notes(current_note_block)
            current_note_block = []

    while len(track.bars) < len(first_track.bars):
        empty = Bar()
        track.addBar(empty)
        track.bars[len(track.bars) - 1].copy_parameters(first_track.bars[len(track.bars) - 1])
        track.bars[len(track.bars) - 1].make_pause()

    return track


def calculate_note_size(ticks, ticks_per_beat):
    return ticks / float(ticks_per_beat * 4)


def fill_song(filename):
    song = get_song_data(filename)
    first_track = fill_first_track(filename)
    song.tracks[0].update_with(first_track)
    for i in range(1, len(song.tracks)):
        song.tracks[i].update_with(fill_nth_track(filename, i, first_track))

    return song
