import matplotlib.pyplot as plt
from mido import MidiFile

plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt

import os
from Analyse import SongAnalyzer


def tempo_converter(value):
    bpm = (1000000 / value) * 60
    return round(bpm, 0)


def make_plot_horizontal(y_values, x_values, title, x_label, tick=5):
    y_values = np.array(y_values)
    y_pos = np.arange(len(y_values))
    performance = np.array(x_values)
    error = np.random.rand(len(y_values))

    plt.xticks(np.arange(0, max(x_values) + 5, tick))

    plt.barh(y_pos, performance)
    plt.yticks(y_pos, y_values)
    plt.xlabel(x_label)
    plt.title(title)
    # plt.savefig(title + '.png')
    plt.show()


def make_plot_vertical(x_values, y_values, title, x_label, tick=5):
    ind = np.arange(len(x_values))
    width = 0.6
    y_values = np.array(y_values)

    p1 = plt.bar(ind, y_values, width, color='r')

    plt.xticks(ind + width / 2., np.array(x_values), rotation='vertical')

    plt.ylabel(x_label)
    plt.title(title)
    # plt.savefig(title + '.png')
    plt.show()


def tempo_change_analysis(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = ["With", "without"]
    xval = [0, 0]
    xlabel = "number of songs"
    title = "the amount of songs with or without tempo change " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_tempo_changes, change = sa.get_all_tempos()
            if number_of_tempo_changes > 1:
                xval[0] += 1
            else:
                xval[1] += 1
        except:
            continue

    make_plot_vertical(yval, xval, title, xlabel)


def signature_change_analysis(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = ["With", "without"]
    xval = [0, 0]
    xlabel = "number of songs"
    title = "the amount of songs with or without signature change " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_signature_changes, change = sa.getAll_time_signatures()
            if number_of_signature_changes > 1:
                xval[0] += 1
            else:
                xval[1] += 1
        except:
            continue

    make_plot_vertical(yval, xval, title, xlabel)


def tempos_for_stable_songs(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = []
    xval = []
    xlabel = "number of songs"
    title = "the appearance of tempos in songs without tempo change " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_tempo_changes, change = sa.get_all_tempos()

            if number_of_tempo_changes == 1:
                change = tempo_converter(change[0])

                if change in yval:
                    index = -1
                    for i in range(0, len(yval)):
                        if change == yval[i]:
                            index = i
                            break
                    xval[index] += 1
                if change not in yval:
                    yval.append(change)
                    xval.append(1)
        except:
            continue

    print()
    yval, xval = (list(t) for t in zip(*sorted(zip(yval, xval))))
    make_plot_vertical(yval, xval, title, xlabel, 2)


def signatures_for_stable_songs(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = []
    xval = []
    xlabel = "number of songs"
    title = "the appearance of signatures for songs without signature change " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_tempo_changes, change = sa.getAll_time_signatures()

            if number_of_tempo_changes == 1:

                if change in yval:
                    index = -1
                    for i in range(0, len(yval)):
                        if change == yval[i]:
                            index = i
                            break
                    xval[index] += 1
                if change not in yval:
                    yval.append(change)
                    xval.append(1)
        except:
            continue

    yval, xval = (list(t) for t in zip(*sorted(zip(yval, xval))))
    make_plot_vertical(yval, xval, title, xlabel, 2)


def tempo_change_frquency(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = []
    xval = []
    xlabel = "number of songs"
    title = "tempo change frequency per track " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_tempo_changes, change = sa.get_all_tempos()
            if number_of_tempo_changes > 1:
                if number_of_tempo_changes in yval:
                    index = -1
                    for i in range(0, len(yval)):
                        if number_of_tempo_changes == yval[i]:
                            index = i
                            break
                    xval[index] += 1
                if number_of_tempo_changes not in yval:
                    yval.append(number_of_tempo_changes)
                    xval.append(1)
        except:
            continue

    yval, xval = (list(t) for t in zip(*sorted(zip(yval, xval))))

    make_plot_vertical(yval, xval, title, xlabel, 2)


def signature_change_frquency(folderName):
    path = '~/Desktop/MusAnalysis/' + folderName
    yval = []
    xval = []
    xlabel = "number of songs"
    title = "signature change frequency per track " + folderName

    for folder in os.listdir(os.path.expanduser(path)):
        npath = path + '/' + folder
        try:
            sa = SongAnalyzer(os.path.expanduser(npath))
            number_of_signature_changes, change = sa.getAll_time_signatures()
            if number_of_signature_changes > 1:
                if number_of_signature_changes in yval:
                    index = -1
                    for i in range(0, len(yval)):
                        if number_of_signature_changes == yval[i]:
                            index = i
                            break
                    xval[index] += 1
                if number_of_signature_changes not in yval:
                    yval.append(number_of_signature_changes)
                    xval.append(1)
        except:
            continue

    yval, xval = (list(t) for t in zip(*sorted(zip(yval, xval))))
    make_plot_vertical(yval, xval, title, xlabel, 2)