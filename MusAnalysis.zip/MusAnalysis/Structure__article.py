from analysis_assistant import *

parts = ['intro', 'verse', 'pre_chorus', 'chorus', 'bridge', 'middle_eight', 'solo', 'outro']


def get_blocks(structure):
    # main
    result_main = []
    result_intro = []
    result_mid = []
    on = False
    start = False
    current = []
    result_outro = []
    for i in range(len(structure)):
        if structure[i] == 'i':
            continue
        if structure[i] == 'v':
            start = True
            if on:
                current.append('v')
            if not on and len(current) > 0:
                result_mid.append(current)
                current = []
                on = True
                continue

            on = True
            continue

        if structure[i] == 'c':
            if on:
                on = False
                result_main.append(current)
                current = []
                continue

        if not start:
            result_intro.append(structure[i])

        if start:
            current.append(structure[i])

        if i + 1 == len(structure) or structure[i + 1] == 'o':
            if current != ['o']:
                result_outro = current
            break
    return result_intro, result_mid, result_main, result_outro


def get_parts_sizes(dataset_line, part):
    result = []
    for i in range(0, len(dataset_line)):
        if dataset_line[i] == part + ':':
            result = dataset_line[i + 1].split(',')
            break
    if result == []:
        return [-1]
    lengths = []
    for i in result:
        diap = i.split('-')
        lengths.append(int(diap[1]) - int(diap[0]) + 1)

    return lengths


def struct_analysis():
    path = '~/Desktop/MusAnalysis/AllHard'

    song_parts = []

    for folder in os.listdir(os.path.expanduser(path)):

        try:
            print(folder)
            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            structure = list()  # structure is here
            raw_structure = list()
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    structure = get_structure(line, numbered=False)
                    raw_structure = get_raw_structure(line)
                    f.close()
                    break

            f.close()

            # for part in parts:
            #     sizes = get_parts_sizes(line, part)
            #     length = len(sizes)
            #     if sizes != [-1]:
            #
            #         comb = Combinator(part + " " + str(length))
            #         index = check_if_in(song_parts, comb)
            #         if index == -1:
            #             for i in sizes:
            #                 if i == -2:
            #                     print("!!!!!" + part)
            #                     print(sizes)
            #
            #                 comb.add(i)
            #             song_parts.append(comb)
            #         else:
            #             for i in sizes:
            #                 song_parts[index].add(i)

            for part in parts:
                sizes = get_parts_sizes(line, part)
                length = len(sizes)
                if sizes != [-1]:

                    comb = Combinator(part + " " + str(length))
                    index = check_if_in(song_parts, comb)
                    if index == -1:
                        comb.add(sizes)
                        song_parts.append(comb)
                    else:
                        song_parts[index].add(sizes)



                        # song = fill_song(os.path.expanduser(npath))

        except Exception as exception:
            print(folder)
            print(line)
            print(exception)
            continue

    for i in song_parts:
        print(i.main)
        print(i.children)
        print(i.amounts)

    for i in song_parts:
        xlabel = "Amount, %"
        title = i.main

        children = i.children
        amounts = i.amounts

        percents = []
        total = sum(amounts)
        for k in amounts:
            percents.append(k / total * 100)

        songs_taken = sum(amounts)
        print(title + " " + str(songs_taken))

        children, percents = (list(t) for t in zip(*sorted(zip(children, percents))))

        bar_num = []
        for j in children:
            bar_num.append(', '.join(list(map(str, j))) + " bars")
        Plotting.make_plot_vertical(percents, bar_num, '', xlabel, save=True, name=title)


# struct_analysis()

def struct_parts_analysis():
    path = '~/Desktop/MusAnalysis/AllHard'

    intros = Combinator('intros')
    mids = Combinator('mids')
    mains = Combinator('mains')
    outros = Combinator('outros')

    for folder in os.listdir(os.path.expanduser(path)):

        try:
            print(folder)
            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            raw_structure = list()
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    raw_structure = get_raw_structure(line)
                    f.close()
                    break

            f.close()

            intr, mid, main, outr = get_blocks(raw_structure)

            intros.add(intr)
            outros.add(outr)
            for i in mid:
                mids.add(i)
            for i in main:
                mains.add(i)





        except Exception as exception:
            print(folder)
            print(exception)
            continue

    xlabel = "Amount, %"
    children = outros.children  # !!!!!
    amounts = outros.amounts
    children, amounts = (list(t) for t in zip(*sorted(zip(children, amounts))))
    children_prepared = []
    percents = []
    total = sum(amounts)
    for i in amounts:
        percents.append(i / total * 100)

    lengths = []
    for i in children:
        if i == "None":
            lengths.append(0)
        lengths.append(len(i))

    for i in children:
        if i == []:
            children_prepared.append("None")
        else:
            children_prepared.append(" ".join(i))

    lengths, children_prepared, percents = (list(t) for t in zip(*sorted(zip(lengths, children_prepared, percents))))
    print(lengths)
    print(percents)
    print(children_prepared)
    Plotting.make_plot_vertical(percents, children_prepared, '', xlabel)


def rhythm_analysis():
    path = '~/Desktop/MusAnalysis/AllHard'

    rhythm = []

    for folder in os.listdir(os.path.expanduser(path)):
        try:
            # print(folder)
            npath = path + '/' + folder

            line = list()  # dataset line
            # getting song structure
            f = open('Dataset_Hard', 'r')
            raw_structure = list()
            while True:
                line = f.readline()
                if line == '\n' or line == '':
                    f.close()
                    break
                line = line.split(" ")
                if line[0] == folder:
                    raw_structure = get_raw_structure(line)
                    f.close()
                    break

            f.close()

            song = fill_song(os.path.expanduser(npath))

            names, rhythms = song.get_all_bars_rhythms()

            for i in range(len(names)):
                song_part = position_to_part(line, i)
                try:
                    names[i] += ' in ' + song_part

                except:
                    print('*' * 10)
                    print(song_part)
                    print(i)
                    print(line)
                    print('*' * 10)

                rhythm_combinator = Combinator(names[i])
                index = check_if_in(rhythm, rhythm_combinator)
                if index == -1:
                    rhythm_combinator.add(rhythms[i])
                    rhythm.append(rhythm_combinator)
                else:
                    rhythm[index].add(rhythms[i])







        except Exception as exception:
            print(folder)
            print(exception)
            continue


    for i in rhythm:
        title = i.main
        children = i.children
        amounts = i.amounts

        percents = []
        total = sum(amounts)
        for j in amounts:
            percents.append(j / total * 100)
        xlabel = "Amount, %"
        fake = []
        for i in range(len(children)):
            fake.append(i)
        children, percents = (list(t) for t in zip(*sorted(zip(children, percents))))
        print(title)
        print(children)
        print("--" * 10)
        # Plotting.make_plot_vertical(percents, fake, '', xlabel, save=True, name=title)
    print(len(rhythm))


rhythm_analysis()

