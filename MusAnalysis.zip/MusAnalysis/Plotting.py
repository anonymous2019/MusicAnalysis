import matplotlib.pyplot as plt
from matplotlib import collections as mc
import pylab as pl

plt.rcdefaults()
import numpy as np
import seaborn as sns


# midi = 'deep_purple-perfect_strangers.mid'
# midi = 'acdc-are_you_ready.mid'
# midi = "Dragonforce - Through the Fire and Flames (Version 1).mid"
# midi = "slayer-disciple.mid"
# midi = 'acdc-highway_to_hell.mid'

def draw_simple(structure, save=False, name='unnamed'):
    x1 = 0
    x2 = 0
    ys = 0

    lines = []
    for i in range(0, len(structure)):
        x2 = x1 + 1
        y = structure[i]
        if ys < y:
            ys = y

        lines.append([(x1, y), (x2, y)])
        x1 = x2

    lc = mc.LineCollection(lines, linewidths=2)
    fig, ax = pl.subplots()
    ax.add_collection(lc)
    ax.autoscale()
    ax.margins(0.1)

    plt.xticks(np.arange(0, x2 + 1, 5), rotation='vertical')
    plt.yticks(np.arange(0, ys + 3, 1))
    if save == False:
        plt.show()
    else:
        plt.savefig(name + '.png', bbox_inches='tight')

    plt.close("all")


def draw_dots(dots):
    lines = []
    for i in range(0, len(dots)):
        lines.append([(dots[i], 0), (dots[i] + 0.01, 0)])

    lc = mc.LineCollection(lines, linewidths=2)

    fig, ax = pl.subplots()
    ax.add_collection(lc)
    ax.autoscale()
    ax.margins(0.1)

    # plt.scatter(*zip(*dots))
    plt.show()


def make_plot_horizontal(y_values, x_values, title, x_label, tick=5):
    y_values = np.array(y_values)
    y_pos = np.arange(len(y_values))
    performance = np.array(x_values)
    error = np.random.rand(len(y_values))

    plt.xticks(np.arange(0, max(x_values) + 5, tick))

    plt.barh(y_pos, performance)
    plt.yticks(y_pos, y_values)
    plt.xlabel(x_label)
    plt.title(title)
    # plt.savefig(title + '.png')
    plt.show()


def make_plot_vertical(y_values, x_values, title, x_label, tick=5, save=False, name='unnamed'):
    ind = np.arange(len(x_values))
    width = 0.6
    y_values = np.array(y_values)

    p1 = plt.bar(ind, y_values, width, color='r')

    plt.xticks(ind + width / 2., np.array(x_values), rotation='vertical')

    plt.ylabel(x_label)
    plt.title(title)
    # plt.savefig(title + '.png')
    if save == False:
        plt.show()
    else:
        plt.savefig(name + '.png', bbox_inches='tight')

    plt.close("all")



def misc_plot(xval, yval, title, xlabel):
    yval, xval = (list(t) for t in zip(*sorted(zip(yval, xval))))
    make_plot_vertical(yval, xval, title, xlabel, 2)
