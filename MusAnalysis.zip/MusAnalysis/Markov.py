from Histograms import Dictogram
import random


def make_markov_model(data):
    markov_model = dict()

    for i in range(0, len(data) - 1):
        if data[i] in markov_model:
            # We have to just append to the existing histogram
            markov_model[data[i]].update([data[i + 1]])
        else:
            markov_model[data[i]] = Dictogram([data[i + 1]])
    return markov_model


def make_higher_order_markov_model(order, data):
    markov_model = dict()

    for i in range(0, len(data) - order):
        # Create the window
        window = tuple(data[i: i + order])
        # Add to the dictionary
        if window in markov_model:
            # We have to just append to the existing Dictogram
            markov_model[window].update([data[i + order]])
        else:
            markov_model[window] = Dictogram([data[i + order]])
    return markov_model


def generate_random_start(model):
    # To just generate any starting word uncomment line:
    # return random.choice(model.keys())

    # To generate a "valid" starting word use:
    # Valid starting words are words that started a sentence in the corpus
    # if 'END' in model:
    #     seed_word = 'END'
    #     while seed_word == 'END':
    #         seed_word = model['END'].return_weighted_random_word()
    #     return seed_word
    # return random.choice(model.keys())
    return 'START'


def generate_random_sentence(length, markov_model):
    current_word = generate_random_start(markov_model)
    sentence = [current_word]
    length = length + 1
    # for i in range(0, length):
    #     current_dictogram = markov_model[current_word]
    #     random_weighted_word = current_dictogram.return_weighted_random_word()
    #     current_word = random_weighted_word
    #     if current_word == 'END' and i < length:
    #         continue

    i = 0
    stuck = 0
    while i < length:
        current_dictogram = markov_model[current_word]
        random_weighted_word = current_dictogram.return_weighted_random_word()
        previous = current_word
        current_word = random_weighted_word

        if stuck == 20:
            stuck = 0
            sentence = ['START']
            i = 0
            current_word = 'START'
            continue
            # rand = random.randrange(1, len(sentence) - 1)
            # current_word = sentence[rand - 1]
            # for j in range(rand, len(sentence)):
            #     del sentence[-1]
            #     i -= 1
        if current_word == 'END' and i < length - 1:
            i -= 0
            stuck += 1
            current_word = previous
            continue
        if current_word != 'END' and i == length - 1:
            i -= 0
            current_word = previous
            stuck += 1
            continue

        i += 1
        sentence.append(current_word)
    sentence[0] = sentence[0].capitalize()
    return ' '.join(sentence)
    return sentence


def generate_any_sentence(markov_model):
    current_word = generate_random_start(markov_model)
    sentence = [current_word]
    while current_word != 'END':
        current_dictogram = markov_model[current_word]
        random_weighted_word = current_dictogram.return_weighted_random_word()
        current_word = random_weighted_word
        sentence.append(current_word)
    sentence[0] = sentence[0].capitalize()
    return ' '.join(sentence)


# A = ['START', 'intro', 'verse', 'chorus', 'verse', 'chorus', 'solo', 'outro', 'END']
# B = ['START', 'verse', 'chorus', 'verse', 'chorus', 'solo', 'END']
# C = ['START', 'intro', 'verse', 'chorus', 'verse', 'chorus', 'solo', 'chorus', 'outro', 'END']
#
# mm = make_markov_model(A + B + C)
# sentence = generate_random_sentence(7, mm)
# print(sentence)
