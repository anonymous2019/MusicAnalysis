from mido import MidiFile
from mido import MidiTrack

mid = MidiFile('acdc-highway_to_hell.mid')


# deep_purple-smoke_on_the_water.mid

# gets tempo of the given track
class SongAnalyzer:
    def __init__(self, midi_path):
        self.midi = MidiFile(midi_path)
        self.name = midi_path

    def get_tempo(self):
        tracks = self.midi.tracks
        for i in range(0, len(tracks)):
            for j in range(0, len(tracks[i])):
                if tracks[i][j].type == 'set_tempo':
                    return tracks[i][j].tempo

    def get_all_tempos(self):
        result = 0
        tempos = []
        tracks = self.midi.tracks
        for i in range(0, len(tracks)):
            for j in range(0, len(tracks[i])):
                if tracks[i][j].type == 'set_tempo':
                    result += 1
                    tempos.append(tracks[i][j].tempo)
        return result, tempos

    def getAll_time_signatures(self):
        result = 0
        tempos = []
        tracks = self.midi.tracks
        for i in range(0, len(tracks)):
            for j in range(0, len(tracks[i])):
                if tracks[i][j].type == 'time_signature':
                    result += 1
                    num = tracks[i][j].numerator
                    denom = tracks[i][j].denominator
                    tempos.append(str(num) + "/" + str(denom))
        return result, tempos

    # transforms ticks into note length 1/4 = 0.25, etc.
    def get_size_from_ticks(self, tempo, ticks, tpb):
        seconds_per_tick = tempo / float(tpb * 4)
        return ticks * seconds_per_tick / tempo

    # returns a list of notes' length of a track
    def track_to_size_list(self, track):
        tempo = self.get_tempo()
        result = []
        for i in range(0, len(track)):
            if (track[i].type == 'note_off' or track[i].type == 'note_on') and track[i].time > 0:
                result.append(round(self.get_size_from_ticks(tempo, track[i].time, mid.ticks_per_beat), 5))
        return result

    # returns a list of lists beat by beat
    def cut(self, track):
        result = []
        current = []
        for element in track:
            if element >= 1 and self.remains(current) > 0.01:
                remaining = self.remains(current)
                current.append(remaining)
                element -= remaining
                result.append(current)
                current = []
            if element >= 1 and self.remains(current) <= 0.01:
                result.append(current)
                current = []
            while element > 1:
                result.append([1])
                element -= 1

            if self.remains(current) + 0.01 < element and self.remains(current) >= 0.01:
                remaining = self.remains(current)
                current.append(remaining)
                element -= remaining
                result.append(current)
                current = []

            if self.beat_full(current, element):
                result.append(current)
                current = []
            current.append(element)

        if self.remains(current) > 0.011:
            current.append(self.remains(current))
            result.append(current)
        elif self.remains(current) <= 0.01:
            result.append(current)
        return result

    # trash
    def regularize(self, track):
        n = len(track)
        for i in range(0, n):
            if track[i] > 1:
                temp = track[i]
                remains = temp % 1
                track.remove(track[i])
                n = int(temp // 1)
                if remains > 0:
                    track = self.insert_with_shift(remains, track, i)

                for j in range(0, n):
                    track = self.insert_with_shift(1, track, i)

        return track

    # trash
    def regularize_after_cut(self, track):
        while [] in track:
            track.remove([])

        n = len(track)
        for i in range(0, n):
            if i + 1 < len(track):
                if self.not_enough(track[i]) and track[i + 1][0] >= 0.99:
                    track[i].append(self.remains(track[i]))
                    track[i + 1][0] -= self.remains(track[i])
            else:
                if self.not_enough(track[i]):
                    track[i].append(self.remains(track[i]))
        return track

    def insert_with_shift(self, element, list, index):
        result = []
        for i in range(0, index):
            result.append(list[i])
        result.append(element)
        for i in range(index, len(list)):
            result.append(list[i])
        return result

    def not_enough(self, list):
        sum = 0
        for elem in list:
            sum += elem
        if sum < 0.8:
            return True
        else:
            return False

    def remains(self, list):
        result = 1
        for elem in list:
            result -= elem
        return result

    def beat_full(self, list, value):
        sum = 0
        for element in list:
            sum += element
        if sum + value > 1:
            return True
        else:
            return False

    def help(self, track):
        for i in range(0, len(track)):
            if (sum(track[i])) != 1:
                print(str(i) + ", " + str(sum(track[i])))
                print(track[i])

    def sum(self, _list):
        result = 0
        for elem in _list:
            result += elem
        return result

    def get_all_tracks(self):
        result = []
        for track in self.midi.tracks:
            result.append(self.cut(self.track_to_size_list(track)))
        return result

    def get_one_track(self, track_num):
        result = []
        track = []
        if track_num >= len(self.midi.tracks):
            track = self.midi.tracks[len(self.midi.tracks) - 1]
        else:
            track = self.midi.tracks[track_num]
        return self.cut(self.track_to_size_list(track))
