from Analyse import SongAnalyzer
from StructureTest import StructureFinder
import copy
import matplotlib.pyplot as plt
import plotly.plotly as py
import plotly.tools as tls

py.sign_in('Timmagg', 'brn7cqrc2r')


class PlotMaker:
    def __init__(self, sa, sf):
        self.song_analyzer = sa
        self.structure_finder = sf

    def draw_plot_for_length(self, length , track):
        self.structure_finder = StructureFinder(sa, track)
        df1 = self.structure_finder.to_dict(length)

        xlim = len(sa.get_all_tracks()[0]) - 1
        ylim = self.structure_finder.get_part_number(length) + 1
        plt.title('Equal parts for length ' + str(length) + "track" + str(track))
        plt.xlim([0, xlim])
        plt.ylim([0, ylim])
        plt.grid(True)

        fig = plt.gcf()
        plotly_fig = tls.mpl_to_plotly(fig)
        plotly_fig['layout']['shapes'] = list()

        for elem in df1:
            plotly_fig['layout']['shapes'].append(dict(type='line', x0=elem.get('start'), y0=elem.get('track'),
                                                       x1=elem.get('finish'), y1=elem.get('track')))

        plotly_fig['data'] = []
        plotly_fig['data'].append({'x': 2, 'y': 1, 'type': 'scatter', 'mode': 'text', 'text': ''})
        plotly_url = py.plot(plotly_fig, filename='mpl-song parts for' + str(self.song_analyzer.name) +
                                                  "length = " + str(length))

# --------------------------------

sa = SongAnalyzer('acdc-highway_to_hell.mid')
sf = StructureFinder(sa)
pm = PlotMaker(sa, sf)
pm.draw_plot_for_length(2, 4)
